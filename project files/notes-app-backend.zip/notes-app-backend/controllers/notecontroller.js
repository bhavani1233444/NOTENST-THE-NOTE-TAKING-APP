const Note = require('../models/Note');

// Get Notes
exports.getNotes = async (req, res) => {
  try {
    const notes = await Note.find({ user: req.user.id });
    res.json(notes);
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// Create Note
exports.createNote = async (req, res) => {
  const { title, description, tag } = req.body;

  try {
    const note = new Note({
      title,
      description,
      tag,
      user: req.user.id,
    });

    await note.save();
    res.status(201).json(note);
  } catch (err) {
    res.status(500).json({ message: err });
  }
};

// Update Note
exports.updateNote = async (req, res) => {
  const { title, description, tag } = req.body;

  try {
    const note = await Note.findById(req.params.id);

    if (!note || note.user.toString() !== req.user.id) {
      return res.status(404).json({ message: 'Note not found or unauthorized' });
    }

    note.title = title || note.title;
    note.description = description || note.description;
    note.tag = tag || note.tag;

    await note.save();
    res.json(note);
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// Delete Note
exports.deleteNote = async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);

    if (!note || note.user.toString() !== req.user.id) {
      return res.status(404).json({ message: 'Note not found or unauthorized' });
    }
    await note.deleteOne();
    res.json({ message: 'Note deleted' });
  } catch (err) {
    res.status(500).json({ message: err });
  }
};

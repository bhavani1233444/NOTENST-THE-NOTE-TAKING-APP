const express = require('express');
const { registerUser, loginUser, getUser, updatePassword, deleteAccount } = require('../controllers/authController');
const fetchUser = require('../middleware/fetchUser');
const passwordUpdate = require('../middleware/updatepassword');

const router = express.Router();

router.post('/register', registerUser);
router.post('/login', loginUser);
router.get('/getuser', fetchUser, getUser);
router.put('/update-password', passwordUpdate, updatePassword);
router.delete('/deleteaccount', fetchUser, deleteAccount);

module.exports = router;
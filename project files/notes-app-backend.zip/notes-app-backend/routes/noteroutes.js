const express = require('express');
const { getNotes, createNote, updateNote, deleteNote } = require('../controllers/noteController');
const router = express.Router();
const { protect } = require('../middleware/authMiddleware');

router.get('/fetchnotes',protect, getNotes);
router.post('/addnote',protect, createNote);
router.put('/updatenote/:id',protect, updateNote);
router.delete('/deletenote/:id',protect, deleteNote);

module.exports = router;
